﻿using System.Web.Mvc;

namespace ResourceServer__Web_API_v1_.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
